
class L4Messaging:

    @staticmethod
    def build(
        symbol,
        l1_result,
        tactical_result
    ):

        lines = []

        lines.append("=" * 60)
        lines.append(f"SYMBOL: {symbol}")
        lines.append("=" * 60)

        lines.append(
            f"L1 STATUS: "
            f"{l1_result.regime_state}"
        )

        lines.append(
            f"TACTICAL STATE: "
            f"{tactical_result['state']}"
        )

        lines.append(
            f"CONFIDENCE: "
            f"{tactical_result['confidence']}"
        )

        lines.append(
            f"MESSAGE: "
            f"{tactical_result['message']}"
        )

        return "\n".join(lines)
