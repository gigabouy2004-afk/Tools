
from CONFIG.settings import (
    MACD_CROSSOVER_DISTANCE
)


class L2Orchestrator:

    @staticmethod
    def process(
        symbol,
        macd_1d,
        macd_4h=None
    ):

        if (
            macd_1d.histogram_slope < 0 and
            macd_1d.crossover_distance <=
            MACD_CROSSOVER_DISTANCE
        ):

            if macd_4h:

                if macd_4h.macd < macd_4h.signal:

                    return {
                        "state": "PRE_BEAR",
                        "confidence": "HIGH",
                        "message": (
                            "1D hinted deterioration and "
                            "4H confirmed bearish crossover."
                        )
                    }

                if macd_4h.macd > macd_4h.signal:

                    return {
                        "state": "PRE_BULL",
                        "confidence": "MEDIUM",
                        "message": (
                            "1D hinted improvement and "
                            "4H confirmed bullish crossover."
                        )
                    }

        return {
            "state": "STANDARD_TREND",
            "confidence": "LOW",
            "message": (
                "No confirmed tactical crossover."
            )
        }
