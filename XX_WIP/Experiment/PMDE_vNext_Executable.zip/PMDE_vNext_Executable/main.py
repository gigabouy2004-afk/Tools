
from datetime import datetime

from IO.data_loader import DataLoader

from LAYERS.L3.macd_engine import MACDEngine
from LAYERS.L3.ema_engine import EMAEngine

from LAYERS.L1.l1_engine import L1Engine
from LAYERS.L2.l2_orchestrator import L2Orchestrator
from LAYERS.L4.l4_messaging import L4Messaging

from CORE.baseline_registry import BaselineRegistry


SYMBOLS = [
    "AOSL",
    "NVDA",
    "AMD",
    "AMAT"
]


def run_symbol(symbol):

    print(f"Processing {symbol}")

    df_1d = DataLoader.load(symbol, "1d")

    ema_result = EMAEngine.get_ema200(df_1d)

    macd_1d = MACDEngine.get_macd(
        df_1d,
        "1d"
    )

    l1_result = L1Engine.evaluate(
        macd_1d.histogram_slope
    )

    macd_4h = None

    if l1_result.escalation_required:

        df_4h = DataLoader.load(
            symbol,
            "4h"
        )

        macd_4h = MACDEngine.get_macd(
            df_4h,
            "4h"
        )

    tactical = L2Orchestrator.process(
        symbol=symbol,
        macd_1d=macd_1d,
        macd_4h=macd_4h
    )

    message = L4Messaging.build(
        symbol,
        l1_result,
        tactical
    )

    print(message)

    BaselineRegistry.update({
        "symbol": symbol,
        "timestamp": datetime.utcnow(),
        "l1_state": l1_result.regime_state,
        "tactical_state": tactical["state"],
        "ema_distance_pct":
            ema_result["distance_pct"],
        "macd_histogram":
            macd_1d.histogram,
        "histogram_slope":
            macd_1d.histogram_slope
    })


def main():

    for symbol in SYMBOLS:

        try:

            run_symbol(symbol)

        except Exception as error:

            print(
                f"[ERROR] "
                f"{symbol} => {error}"
            )


if __name__ == "__main__":
    main()
