
import pandas as pd
from pathlib import Path
from CONFIG.settings import BASELINE_FILE


class BaselineRegistry:

    @staticmethod
    def load():

        path = Path(BASELINE_FILE)

        if not path.exists():
            return pd.DataFrame()

        return pd.read_csv(path)


    @staticmethod
    def update(record: dict):

        path = Path(BASELINE_FILE)

        if path.exists():
            df = pd.read_csv(path)
        else:
            df = pd.DataFrame()

        df = df[df["symbol"] != record["symbol"]]                     if not df.empty else df

        df = pd.concat([
            df,
            pd.DataFrame([record])
        ], ignore_index=True)

        df.to_csv(path, index=False)
